#include <iostream>     // std::cout
#include <limits>       // std::numeric_limits

/// <summary>
/// Template function to abstract away the logic of:
///   start + (increment * steps)
/// This function performs addition in a loop and checks for overflow.
/// </summary>
/// <typeparam name="T">A type that supports basic math functions</typeparam>
/// <param name="start">The initial value</param>
/// <param name="increment">The value to add on each step</param>
/// <param name="steps">The number of times the increment is added</param>
/// <returns>The result of start + (increment * steps)</returns>
template <typename T>
T add_numbers(T const& start, T const& increment, unsigned long int const& steps)
{
    T result = start;  // Initialize result with the start value

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Check if adding the increment would cause overflow
        if (std::numeric_limits<T>::max() - result < increment)
        {
            std::cout << "Overflow detected!" << std::endl;
            return std::numeric_limits<T>::max(); // Return max value to indicate overflow
        }

        result += increment;  // Add the increment to result if safe
    }

    return result;  // Return the final result
}

/// <summary>
/// Template function to abstract away the logic of:
///   start - (decrement * steps)
/// This function performs subtraction in a loop and checks for underflow.
/// </summary>
/// <typeparam name="T">A type that supports basic math functions</typeparam>
/// <param name="start">The initial value</param>
/// <param name="decrement">The value to subtract on each step</param>
/// <param name="steps">The number of times the decrement is subtracted</param>
/// <returns>The result of start - (decrement * steps)</returns>
template <typename T>
T subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps)
{
    T result = start;  // Initialize result with the start value

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Check if subtracting the decrement would cause underflow
        if (result - std::numeric_limits<T>::min() < decrement)
        {
            std::cout << "Underflow detected!" << std::endl;
            return std::numeric_limits<T>::min(); // Return min value to indicate underflow
        }

        result -= decrement;  // Subtract the decrement from result if safe
    }

    return result;  // Return the final result
}

/// <summary>
/// Function to test for overflow when adding numbers.
/// It prints the result and checks if an overflow occurred.
/// </summary>
/// <typeparam name="T">The data type being tested (e.g., int, float)</typeparam>
template <typename T>
void test_overflow()
{
    // Parameters for the test
    const unsigned long int steps = 5;  // Number of iterations
    const T increment = std::numeric_limits<T>::max() / steps;  // Increment per step
    const T start = 0;  // Start at 0

    std::cout << "Overflow Test of Type = " << typeid(T).name() << std::endl;

    // Perform addition without overflow
    std::cout << "\tAdding Numbers Without Overflow (" << +start << ", " << +increment << ", " << steps << ") = ";
    T result = add_numbers<T>(start, increment, steps);
    std::cout << +result << std::endl;

    // Perform addition that causes overflow
    std::cout << "\tAdding Numbers With Overflow (" << +start << ", " << +increment << ", " << (steps + 1) << ") = ";
    result = add_numbers<T>(start, increment, steps + 1);

    if (result == std::numeric_limits<T>::max())  // Check if overflow occurred
    {
        std::cout << "\tOverflow occurred!" << std::endl;
    }
    else
    {
        std::cout << +result << std::endl;  // Print result if no overflow
    }
}

/// <summary>
/// Function to test for underflow when subtracting numbers.
/// It prints the result and checks if an underflow occurred.
/// </summary>
/// <typeparam name="T">The data type being tested (e.g., int, float)</typeparam>
template <typename T>
void test_underflow()
{
    // Parameters for the test
    const unsigned long int steps = 5;  // Number of iterations
    const T decrement = std::numeric_limits<T>::max() / steps;  // Decrement per step
    const T start = std::numeric_limits<T>::max();  // Start at max value

    std::cout << "Underflow Test of Type = " << typeid(T).name() << std::endl;

    // Perform subtraction without underflow
    std::cout << "\tSubtracting Numbers Without Underflow (" << +start << ", " << +decrement << ", " << steps << ") = ";
    T result = subtract_numbers<T>(start, decrement, steps);
    std::cout << +result << std::endl;

    // Perform subtraction that causes underflow
    std::cout << "\tSubtracting Numbers With Underflow (" << +start << ", " << +decrement << ", " << (steps + 1) << ") = ";
    result = subtract_numbers<T>(start, decrement, steps + 1);

    if (result == std::numeric_limits<T>::min())  // Check if underflow occurred
    {
        std::cout << "\tUnderflow occurred!" << std::endl;
    }
    else
    {
        std::cout << +result << std::endl;  // Print result if no underflow
    }
}

/// <summary>
/// Function to run all overflow tests on different data types.
/// </summary>
/// <param name="star_line">Line of stars to separate output sections</param>
void do_overflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Overflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Test overflow for various types
    test_overflow<char>();
    test_overflow<wchar_t>();
    test_overflow<short int>();
    test_overflow<int>();
    test_overflow<long>();
    test_overflow<long long>();
    test_overflow<unsigned char>();
    test_overflow<unsigned short int>();
    test_overflow<unsigned int>();
    test_overflow<unsigned long>();
    test_overflow<unsigned long long>();
    test_overflow<float>();
    test_overflow<double>();
    test_overflow<long double>();
}

/// <summary>
/// Function to run all underflow tests on different data types.
/// </summary>
/// <param name="star_line">Line of stars to separate output sections</param>
void do_underflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Underflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Test underflow for various types
    test_underflow<char>();
    test_underflow<wchar_t>();
    test_underflow<short int>();
    test_underflow<int>();
    test_underflow<long>();
    test_underflow<long long>();
    test_underflow<unsigned char>();
    test_underflow<unsigned short int>();
    test_underflow<unsigned int>();
    test_underflow<unsigned long>();
    test_underflow<unsigned long long>();
    test_underflow<float>();
    test_underflow<double>();
    test_underflow<long double>();
}

/// <summary>
/// Entry point into the application. Runs both overflow and underflow tests.
/// </summary>
/// <returns>0 when complete</returns>
int main()
{
    const std::string star_line = std::string(50, '*');  // Creates a line of stars for output formatting

    std::cout << "Starting Numeric Underflow / Overflow Tests!" << std::endl;

    do_overflow_tests(star_line);  // Run all overflow tests
    do_underflow_tests(star_line);  // Run all underflow tests

    std::cout << std::endl << "All Numeric Underflow / Overflow Tests Complete!" << std::endl;

    return 0;  // Program ends successfully
}
