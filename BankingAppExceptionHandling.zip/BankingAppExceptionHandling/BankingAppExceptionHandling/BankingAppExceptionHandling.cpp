#include <iostream>
#include <stdexcept>

// Custom exception class derived from std::exception
class CustomException : public std::exception {
public:
    const char* what() const noexcept override {
        return "Custom exception occurred!";
    }
};

// Function that can throw a standard exception
bool do_even_more_custom_application_logic() {
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    // Throwing a standard exception
    throw std::runtime_error("Standard exception: Something went wrong in even more logic.");

    return true; // This won't be reached because of the exception
}

// Function to encapsulate custom application logic
void do_custom_application_logic() {
    try {
        std::cout << "Running Custom Application Logic." << std::endl;

        // Wrapping the call to do_even_more_custom_application_logic() in an exception handler
        if (do_even_more_custom_application_logic()) {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e) {
        // Catching std::exception and displaying the exception message
        std::cerr << "Caught exception: " << e.what() << std::endl;
    }

    // Throwing a custom exception derived from std::exception
    throw CustomException();
}

// Function to handle division and catch divide by zero
float divide(float num, float den) {
    if (den == 0) {
        // Throwing a standard exception for divide by zero errors
        throw std::invalid_argument("Divide by zero exception.");
    }
    return num / den;
}

// Division logic wrapped with exception handling
void do_division() noexcept {
    try {
        float numerator = 10.0f;
        float denominator = 0.0f;

        // Attempting division and handling potential divide by zero errors
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::invalid_argument& e) {
        // Catching and displaying the divide by zero error
        std::cerr << "Caught divide by zero error: " << e.what() << std::endl;
    }
}

int main() {
    try {
        std::cout << "Exceptions Tests!" << std::endl;

        // Running division logic
        do_division();

        // Running custom application logic
        do_custom_application_logic();
    }
    catch (const CustomException& e) {
        // Catching custom exceptions
        std::cerr << "Caught custom exception in main: " << e.what() << std::endl;
    }
    catch (const std::exception& e) {
        // Catching standard exceptions
        std::cerr << "Caught standard exception in main: " << e.what() << std::endl;
    }
    catch (...) {
        // Catching all other exceptions
        std::cerr << "Caught unknown exception in main!" << std::endl;
    }

    return 0;
}
